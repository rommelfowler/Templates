	<footer class="entry-footer">
		<?php business_entry_footer(); ?>
	</footer><!-- .entry-footer -->