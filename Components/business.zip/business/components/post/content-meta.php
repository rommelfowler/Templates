		<div class="entry-meta">
			<?php business_posted_on(); ?>
		</div><!-- .entry-meta -->