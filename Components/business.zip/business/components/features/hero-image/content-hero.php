<?php
/**
 * The template used for displaying hero content
 *
 * @package Blog_Theme
 */
?>

<?php if ( has_post_thumbnail() ) : ?>
	<div class="business-hero">
		<?php the_post_thumbnail( 'business-hero' ); ?>
	</div>
<?php endif; ?>
