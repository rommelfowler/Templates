	<footer class="entry-footer">
		<?php magazine_entry_footer(); ?>
	</footer><!-- .entry-footer -->