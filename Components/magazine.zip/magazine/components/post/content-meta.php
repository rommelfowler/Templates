		<div class="entry-meta">
			<?php magazine_posted_on(); ?>
		</div><!-- .entry-meta -->