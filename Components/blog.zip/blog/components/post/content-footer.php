	<footer class="entry-footer">
		<?php blog_entry_footer(); ?>
	</footer><!-- .entry-footer -->