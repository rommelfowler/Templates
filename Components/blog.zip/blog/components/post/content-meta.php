		<div class="entry-meta">
			<?php blog_posted_on(); ?>
		</div><!-- .entry-meta -->