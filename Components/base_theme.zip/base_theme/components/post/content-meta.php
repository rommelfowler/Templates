		<div class="entry-meta">
			<?php base_theme_posted_on(); ?>
		</div><!-- .entry-meta -->