	<footer class="entry-footer">
		<?php blog_modern_entry_footer(); ?>
	</footer><!-- .entry-footer -->