		<div class="entry-meta">
			<?php blog_modern_posted_on(); ?>
		</div><!-- .entry-meta -->