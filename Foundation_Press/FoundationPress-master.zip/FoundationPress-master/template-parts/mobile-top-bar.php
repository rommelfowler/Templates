<?php
/**
 * Template part for off canvas menu
 *
 * @package FoundationPress
 * @since FoundationPress 1.0.0
 */

?>

<nav class="vertical menu" id="mobile-menu" role="navigation">
  <?php foundationpress_mobile_nav(); ?>
</nav>
